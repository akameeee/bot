# GoodMorn BOT
Bot Gift Biji Goodmorn
Cara pakai install termux Ketik

pkg install php

pkg install git

git clone https://github.com/mrpaciko/Goodmorn/

cd bot

php Gmorn.php

Source code by : Brain
